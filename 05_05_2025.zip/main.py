import pygame
import sys

pygame.init()

# Screen setup
WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bird View Game")

clock = pygame.time.Clock()
# Desired size
# Desired size
PLAYER_WIDTH, PLAYER_HEIGHT = 64, 64  # adjust these values as needed

# Load and scale images
player_images = {
    "down": pygame.transform.scale(pygame.image.load("./images/player_up.png"), (PLAYER_WIDTH, PLAYER_HEIGHT)),
    "up": pygame.transform.scale(pygame.image.load("./images/player_down.png"), (PLAYER_WIDTH, PLAYER_HEIGHT)),
    "left": pygame.transform.scale(pygame.image.load("./images/player_left.png"), (PLAYER_WIDTH, PLAYER_HEIGHT)),
    "right": pygame.transform.scale(pygame.image.load("./images/player_right.png"), (PLAYER_WIDTH, PLAYER_HEIGHT))
}




# Player settings
player_speed = 0.9
player_pos = pygame.Vector2(WIDTH // 12 , HEIGHT // 12)
current_direction = "down"

# Main game loop
running = True
while running:
    screen.fill((30, 30, 30))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_UP]:
        player_pos.y -= player_speed
        current_direction = "up"
    elif keys[pygame.K_DOWN]:
        player_pos.y += player_speed
        current_direction = "down"
    elif keys[pygame.K_LEFT]:
        player_pos.x -= player_speed
        current_direction = "left"
    elif keys[pygame.K_RIGHT]:
        player_pos.x += player_speed
        current_direction = "right"

    # Draw player with current direction
    screen.blit(player_images[current_direction], player_pos)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
